package com.stock.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.stock.entity.Stock;
import com.stock.entity.User;
import com.stock.service.StockService;
import com.stock.util.Condition;
import com.stock.util.UtilStock;

@Controller
public class StockController {
	
	@Autowired
	private StockService stockService ;
     
	  @RequestMapping("to/stock")
	  public String tostock(Model model) {
		  List<Stock> stocks = stockService.selectStocks();
		  model.addAttribute("list", stocks);
		   return "在庫情報一覧";
	  }
	  @RequestMapping("to/deletestock")
	  public String deletestock(String id,Model model) {
		  if(id==""||id==null) {
			  model.addAttribute("err", "削除内容を選択してください。");
			    return "forward:/to/stock";
		    }
		  int id1 =Integer.valueOf(id);
		  stockService.deletestockAndstockIo(id1);
		  
		  return "forward:/to/stock";
	  }

	      @RequestMapping("/to/add")
          public String add(int id,Model model) {
	    	  Stock stock = stockService.selectStockById(id);
	    	  model.addAttribute("stock", stock);  	  
        	  return "在庫情報登録";
          }
	      @RequestMapping("/add")
          public String updatStock(UtilStock utilStock,HttpSession session) {
	    	  int maxId = stockService.selectMaxId()+1;
	    	 int id = Integer.valueOf(utilStock.getId());
	    	   if(id<maxId) {            
	    		   Stock stock =new Stock();
               BeanUtils.copyProperties(utilStock, stock);
               stock.setId(id );
              User user = (User)session.getAttribute("user");
 	    	  stock.setUpdateUser(user.getUserName());
 	    	  Date date = new Date();
 	    	  SimpleDateFormat dateFormat= new SimpleDateFormat("yyyy/MM/dd hh:mm:ss");	    	
 	    	  stock.setUpdateDate(dateFormat.format(date));
               stockService.updateStock(stock);
	    	  return "forward:/to/stock";}else {
	              Stock stock =new Stock();
	              BeanUtils.copyProperties(utilStock, stock);
	              stock.setId(Integer.valueOf(utilStock.getId()) );
	             User user = (User)session.getAttribute("user");
		    	  stock.setUpdateUser(user.getUserName());
		    	  stockService.addStock(stock);
		    	  return "forward:/to/stock";
	    	  }

          }
	      @RequestMapping("/to/add/to/stock")
          public String backtoStock(Model model) {
	    	  
	    	  return "forward:/to/stock";
          }
	      @RequestMapping("/to/add/stock")
          public String add(Model model) {
	    	  int maxId = stockService.selectMaxId()+1;
	    	  Stock stock = new Stock();
	    	  stock.setId(maxId);
	    	  model.addAttribute("stock", stock);
        	  return "在庫情報登録";
          }

	      @RequestMapping("/stocks")
	      public String stocks(Condition condition ,Model model) {
	          if(condition.getStatus()==""&&condition.getName()==""&&condition.getDatebegin()==""&&condition.getDateend()=="") { 	  
	        	   return "在庫情報一覧";	  
	          }
	    	  List<Stock> stockList = stockService.selectByCondition(condition);
	    	  List<Stock> newStock = new ArrayList<>();
	    	  if(condition.getStatus()=="") {
	    		  model.addAttribute("list", stockList);
	    		  return "在庫情報一覧";
	    	  }else {
	    		  if(condition.getStatus().equals("在庫あり")) {
	    			  for(Stock stock :stockList) {
	    				  if(stock.getStockNum()>0) {
	    					  newStock.add(stock);
	    				  }
	    			  }
    				  model.addAttribute("list", newStock);
    				  return "在庫情報一覧";
	    		  }else {
	    			  for(Stock stock :stockList) {
	    				  if(stock.getStockNum()==0) {
	    					  newStock.add(stock);
	    				  }
	    			  }
    				  model.addAttribute("list", newStock);
    				  return "在庫情報一覧";
	    		  }
	    	  }
	      }
}
