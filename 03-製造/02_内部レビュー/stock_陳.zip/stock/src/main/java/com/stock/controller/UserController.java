package com.stock.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.stock.entity.User;
import com.stock.service.UserService;

@Controller
public class UserController {
         @Autowired
	    private UserService userService;
             
     
	  @RequestMapping("/to/login")
	  public String tologin() {

		   return "倉庫ログイン画面";
	  }
	  @RequestMapping("/login")
	  public String login(User user,Model model,HttpSession session) {
		  User user1 = userService.selectByUserId(user.getUserId());
		  User user2 = userService.selectByUser(user);
		  if(user1==null) {
			  model.addAttribute("err", "ID再度入力をしてください");
			  return "倉庫ログイン画面";
		  }else {
			  
		  if(user2==null) {
				  model.addAttribute("err", "パスワードが間違っています。再度入力をしてください");
				  return "倉庫ログイン画面";  

		  }
		  }
		  session.setAttribute("user", user2);
		return "forward:/to/stock";
	  }

}

	


