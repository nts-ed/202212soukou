package com.stock.util;

public class Condition {
	private String status;
	private String name;
	private String datebegin;
	private String dateend;
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDatebegin() {
		return datebegin;
	}
	public void setDatebegin(String datebegin) {
		this.datebegin = datebegin;
	}
	public String getDateend() {
		return dateend;
	}
	public void setDateend(String dateend) {
		this.dateend = dateend;
	}
	@Override
	public String toString() {
		return "Condition [status=" + status + ", name=" + name + ", datebegin=" + datebegin + ", dateend=" + dateend
				+ "]";
	}
	
	
	
}
