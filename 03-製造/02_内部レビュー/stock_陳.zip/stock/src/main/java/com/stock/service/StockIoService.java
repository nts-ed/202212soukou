package com.stock.service;

import java.util.List;

import com.stock.entity.Stock;
import com.stock.entity.StockIo;



public interface StockIoService {
	
	   public  List<StockIo> selectStockIo(int id);
	   
	   public List<StockIo> selectStockIoByTime(String datebegin,String dateend,int type,int id);

	   public int StockIoResult(Integer id);
	   
	   public int insertStockIo(StockIo stockIo);
	   
	   public Stock selectStock(Integer id);
}
