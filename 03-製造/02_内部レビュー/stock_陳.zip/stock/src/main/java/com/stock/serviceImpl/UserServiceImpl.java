package com.stock.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stock.entity.User;
import com.stock.mapper.UserMapper;
import com.stock.service.UserService;

@Service
public class UserServiceImpl implements UserService{
	
	  @Autowired
	  private UserMapper userMapper;


	@Override
	public User selectByUserId(String userId) {
		
		return userMapper.selectByUserId(userId);
	}

	@Override
	public User selectByUser(User user) {

		return userMapper.selectByUser(user);
		
	}



}
