package com.stock.serviceImpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stock.entity.Stock;
import com.stock.mapper.StockMapper;
import com.stock.service.StockService;
import com.stock.util.Condition;

@Service
public class StockServiceImpl  implements StockService{

    @Autowired
   private  StockMapper stockMapper ;
	
	@Override
	public List<Stock> selectStocks() {
		List<Stock> stocks = stockMapper.selectStocks();
		int countIn =0;
		int countOut =0;
		for(Stock stock : stocks ) {
			try {
				 countIn = stockMapper.selectStockIoByIn(stock.getId());			
			} catch (Exception e) {
				stock.setStockNum(0);			
			}	
			try {				
				 countOut = stockMapper.selectStockIoByOut(stock.getId());
				stock.setStockNum(countIn-countOut);
				
			} catch (Exception e) {
				stock.setStockNum(countIn);		
			}
	
		}
		
		
		return stocks;
	}

	@Override
	public int deletestockAndstockIo(Integer id) {
		int count1 = stockMapper.deletestock(id);
		int count2 = stockMapper.deletestockIo(id);
		return count1+count2;
	}

	@Override
	public Stock selectStockById(Integer id) {
	return	stockMapper.selectStockById(id);
		
	}

	@Override
	public int updateStock(Stock stock) {

		return stockMapper.updateStock(stock);
	}

	@Override
	public int selectMaxId() {
		
		return 	stockMapper.selectMaxId();
		
	}

	@Override
	public int addStock(Stock stock) {
		
		
		return  stockMapper.addStock(stock);
		
	}

	@Override
	public List<Stock> selectByCondition(Condition condition) {
		String name = condition.getName();
		if(name==null&&name=="") {
			condition.setName(null);
		}
		List<Stock> stockList = stockMapper.selectByCondition(condition);
		int countIn =0;
		int countOut =0;
		for(Stock stock : stockList ) {
			try {
				 countIn = stockMapper.selectStockIoByIn(stock.getId());			
			} catch (Exception e) {
				stock.setStockNum(0);			
			}	
			try {				
				 countOut = stockMapper.selectStockIoByOut(stock.getId());
				stock.setStockNum(countIn-countOut);
				
			} catch (Exception e) {
				stock.setStockNum(countIn);		
			}
	
		}
			
		return stockList;
	}





}
