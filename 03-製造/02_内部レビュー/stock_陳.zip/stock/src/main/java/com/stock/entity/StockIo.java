package com.stock.entity;

import java.util.Date;


public class StockIo {
        private int id;
        private int ioType;
        private int ioNum;
        private String remarks;
        private int delFlg;
        private String createDate;
        private String createUser;
        
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public int getIoType() {
			return ioType;
		}
		public void setIoType(int ioType) {
			this.ioType = ioType;
		}
		public int getIoNum() {
			return ioNum;
		}
		public void setIoNum(int ioNum) {
			this.ioNum = ioNum;
		}
		public String getRemarks() {
			return remarks;
		}
		public void setRemarks(String remarks) {
			this.remarks = remarks;
		}
		public int getDelFlg() {
			return delFlg;
		}
		public void setDelFlg(int delFlg) {
			this.delFlg = delFlg;
		}
		public String getCreateDate() {
			return createDate;
		}
		public void setCreateDate(String createDate) {
			this.createDate = createDate;
		}
		public String getCreateUser() {
			return createUser;
		}
		public void setCreateUser(String createUser) {
			this.createUser = createUser;
		}
		@Override
		public String toString() {
			return "StockIo [id=" + id + ", ioType=" + ioType + ", ioNum=" + ioNum + ", remarks=" + remarks
					+ ", delFlg=" + delFlg + ", createDate=" + createDate + ", createUser=" + createUser + "]";
		}

	 
	
        
}
