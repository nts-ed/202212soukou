package com.stock.service;

import com.stock.entity.User;

public interface UserService {
	
	public User selectByUserId(String userId );
	public User selectByUser(User user );
	

}
