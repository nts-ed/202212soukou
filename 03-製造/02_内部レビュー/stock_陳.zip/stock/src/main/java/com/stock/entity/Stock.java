package com.stock.entity;

public class Stock {

	  private int id;
	  private String name;
	  private String unit;
	  private int StockNum;
	  private String updateUser; 
	  private String updateDate;
	  private String remarks;
	  
	  
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public int getStockNum() {
		return StockNum;
	}
	public void setStockNum(int stockNum) {
		StockNum = stockNum;
	}
	public String getUpdateUser() {
		return updateUser;
	}
	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}
	public String getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	@Override
	public String toString() {
		return "Stock [id=" + id + ", name=" + name + ", unit=" + unit + ", StockNum=" + StockNum + ", updateUser="
				+ updateUser + ", updateDate=" + updateDate + ", remarks=" + remarks + "]";
	}
	  
	
	

}
