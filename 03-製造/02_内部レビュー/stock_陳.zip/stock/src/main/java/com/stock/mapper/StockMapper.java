package com.stock.mapper;

import java.util.List;

import com.stock.entity.Stock;
import com.stock.util.Condition;

public interface StockMapper {
	
	   public List<Stock> selectStocks();
	
	   public  int selectStockIoByIn(Integer id);
	   
	   public  int selectStockIoByOut(Integer id);
	   
	   public int deletestock(Integer id);
	   
	   public int deletestockIo(Integer id);
	   
	   public Stock selectStockById(Integer id);
	   
	   public int updateStock(Stock stock);
	   
	   public int selectMaxId();
	   
	   public int addStock(Stock stock);
	   
	   public List<Stock>  selectByCondition(Condition condition);

}
