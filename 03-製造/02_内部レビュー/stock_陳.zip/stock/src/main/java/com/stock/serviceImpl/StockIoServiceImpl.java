package com.stock.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stock.entity.Stock;
import com.stock.entity.StockIo;
import com.stock.mapper.StockIoMapper;
import com.stock.service.StockIoService;


@Service
public class StockIoServiceImpl implements StockIoService{
	
	    @Autowired
	   private  StockIoMapper stockIoMapper ;

		@Override
		public List<StockIo> selectStockIo(int id) {
						
			return stockIoMapper.selectStockIo(id);
			
		}
	
		@Override
		public List<StockIo> selectStockIoByTime(String datebegin,String dateend,int type,int id) {
			
			return stockIoMapper.selectStockIoByTime(datebegin,dateend,type,id);
		}

		@Override
		public int StockIoResult(Integer id) {
			int inCount =0;
			int outCount =0;
			try {
				 inCount = stockIoMapper.selectStockIoByIn(id);
				 outCount=stockIoMapper.selectStockIoByOut(id);
			} catch (Exception e) {
				
			}
			
			
			return inCount-outCount;
		}

		@Override
		public int insertStockIo(StockIo stockIo) {
		
			return 	stockIoMapper.insertStockIo(stockIo);
		
		}

		@Override
		public Stock selectStock(Integer id) {
		return	stockIoMapper.selectStock(id);
			
		}

	

}
