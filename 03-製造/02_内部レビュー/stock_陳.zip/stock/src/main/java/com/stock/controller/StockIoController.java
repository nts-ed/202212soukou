package com.stock.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.stock.entity.Stock;
import com.stock.entity.StockIo;
import com.stock.entity.User;
import com.stock.service.StockIoService;


@Controller
public class StockIoController {
      
	@Autowired
	private StockIoService stockIoService ;
     
	  @RequestMapping("/to/stockIo")

	  public String tologin(HttpServletRequest request,String id, Model model) {
		  int id1 =Integer.valueOf(id);
		  Stock stock = stockIoService.selectStock(id1);
		  stock.setStockNum(stockIoService.StockIoResult(id1));
		  model.addAttribute("stock", stock);
		  List<StockIo> stockIo = stockIoService.selectStockIo(id1);
		  model.addAttribute("stockIoList", stockIo);
		   return "入出庫情報";
	  }
	  @RequestMapping("/stockIo") 
	  public String login(String id,String datebegin,String dateend,String type, Model model) {
		  int id1 =Integer.valueOf(id);
		  Stock stock = stockIoService.selectStock(id1);
		  stock.setStockNum(stockIoService.StockIoResult(id1));
		  model.addAttribute("stock", stock);
		 Integer typeNum = Integer.valueOf(type);
         List<StockIo> stockIo = stockIoService.selectStockIoByTime(datebegin,dateend,typeNum,id1);
         model.addAttribute("stockIoList", stockIo);
		  return "入出庫情報";
	  }
	  @RequestMapping("/submit")
	  public String submit(String id,Model model) {
		  int id1 =Integer.valueOf(id);	  
		  Stock stock = stockIoService.selectStock(id1);
		  stock.setStockNum(stockIoService.StockIoResult(id1));
		  model.addAttribute("stock", stock);
		   return "IOSubmit";
	  }
	  @RequestMapping("/to/submit")
	  public String tosubmit(String id,String type,String operationAmount,Model model,HttpSession session) {
		   int id1 =Integer.valueOf(id);
		  User user = (User)session.getAttribute("user");
		  if(operationAmount==""||operationAmount==null) {
		    	model.addAttribute("err", "入出庫数量を入力してください。");
			    return "forward:/submit";
		    }
		  
		     int type1= Integer.valueOf(type);
		     int operationAmount1 = Integer.valueOf(operationAmount);
			 if(type1==1) {
				 StockIo stockIo = new StockIo();
				 stockIo.setCreateUser(user.getUserName());
				 stockIo.setId(id1);
				 stockIo.setIoType(type1);
				 stockIo.setIoNum(operationAmount1);
				 int count = stockIoService.insertStockIo(stockIo);
				 if(count>0) {
					 return "forward:/to/stockIo?id1";
				 }else {
					 return"forward:/submit?id1";
				 }			 		 
			 }else {
				 int stockIoResult = stockIoService.StockIoResult(id1);
				 if(stockIoResult >= operationAmount1) {
					 StockIo stockIo = new StockIo();
					 stockIo.setCreateUser(user.getUserName());
					 stockIo.setId(id1);
					 stockIo.setIoType(type1);
					 stockIo.setIoNum(operationAmount1);
					 int count = stockIoService.insertStockIo(stockIo);
					 if(count>0) {
						 return "forward:/to/stockIo?id1";
					 }else {
						 return"forward:/submit?id1";
					 }	
				 }else {
					 model.addAttribute("err", "在庫数量が不足、ご確認の上、再度入力してください");
					 return"forward:/submit?id1";
				 }
			 } 
	  }


}
