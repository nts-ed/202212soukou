package com.stock.mapper;

import java.util.List;

import com.stock.entity.Stock;
import com.stock.entity.StockIo;



public interface StockIoMapper {
             
	   public  List<StockIo> selectStockIo(int id);
	   
	   public List<StockIo> selectStockIoByTime(String datebegin,String dateend,int type,int id);
		   
	   public  int selectStockIoByIn(Integer id);
	   
	   public  int selectStockIoByOut(Integer id);
	   
	   public int insertStockIo(StockIo stockIo);
	   
	   public Stock selectStock(Integer id);
	   
	  
}
