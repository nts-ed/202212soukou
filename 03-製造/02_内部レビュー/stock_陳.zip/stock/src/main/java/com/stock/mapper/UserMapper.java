package com.stock.mapper;

import org.apache.ibatis.annotations.Param;

import com.stock.entity.User;

public interface UserMapper {
	
	
	public User selectByUserId(String userId );
	public User selectByUser(User user);

}
