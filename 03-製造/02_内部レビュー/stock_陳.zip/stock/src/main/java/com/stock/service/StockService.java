package com.stock.service;

import java.util.List;

import com.stock.entity.Stock;
import com.stock.util.Condition;

public interface StockService {

		
	public List<Stock> selectStocks();
	
	 public int deletestockAndstockIo(Integer id);
	 
	 public Stock selectStockById(Integer id);
	 
	  public int updateStock(Stock stock);
	  
	  public int selectMaxId();
	  
	  public int addStock(Stock stock);
	  
	  public List<Stock>  selectByCondition(Condition condition);
	

}
