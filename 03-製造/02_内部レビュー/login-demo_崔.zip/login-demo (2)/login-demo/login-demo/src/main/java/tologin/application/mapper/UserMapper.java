package tologin.application.mapper;


import tologin.application.entity.User;


public interface UserMapper {

	public User selectByUserId(String userId );
	public User selectByUser(User user );
	
     
}

