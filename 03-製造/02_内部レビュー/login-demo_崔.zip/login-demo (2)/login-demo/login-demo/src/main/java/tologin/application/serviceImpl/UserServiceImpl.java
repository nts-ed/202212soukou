package tologin.application.serviceImpl;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tologin.application.entity.User;
import tologin.application.mapper.UserMapper;
import tologin.application.service.UserService;



@Service
public class UserServiceImpl implements UserService{
	  @Autowired
	  private UserMapper userMapper;


	@Override
	public User selectByUserId(String userId) {
		
		return userMapper.selectByUserId(userId);
	}

	@Override
	public User selectByUser(User user) {
		
		return userMapper.selectByUser(user);
	}






}