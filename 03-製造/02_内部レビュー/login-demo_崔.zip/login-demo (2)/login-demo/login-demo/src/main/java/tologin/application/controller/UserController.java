package tologin.application.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import tologin.application.entity.User;
import tologin.application.service.UserService;

@Controller
@RequestMapping("/user")
public class UserController {
	@Autowired
	private UserService userService;

	@RequestMapping("/to/login")
	public String tologin() {

		return "倉庫ログイン画面";
	}

	@RequestMapping("/login")
	  public String login(User user,Model model,HttpSession session) {
		  User user1 = userService.selectByUserId(user.getUserId());
		  if(user1==null) {
			  model.addAttribute("err", "社員IDが間違っています。再度入力なおしてください");
			  return "倉庫ログイン画面";
		  }else {
			  User user2 = userService.selectByUser(user);
		  if(user2==null) {
				  model.addAttribute("err", "パスワードが間違っています。再度入力しなおしてください");
				  return "倉庫ログイン画面";  

			  }
		  }
		  return "在庫情報一覧";
	  }
}
