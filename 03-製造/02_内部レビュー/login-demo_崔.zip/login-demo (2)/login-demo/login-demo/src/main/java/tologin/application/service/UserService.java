package tologin.application.service;


import tologin.application.entity.User;


public interface UserService {

	

	public User selectByUserId(String userId );
	public User selectByUser(User user );
	

}
