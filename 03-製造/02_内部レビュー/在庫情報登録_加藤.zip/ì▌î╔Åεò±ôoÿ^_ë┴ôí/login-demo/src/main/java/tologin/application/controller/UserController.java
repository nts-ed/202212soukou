package tologin.application.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.server.Session;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import tologin.application.entity.Attendance;
import tologin.application.entity.Employee;
import tologin.application.service.UserService;
import tologin.application.utill.GetWorkDay;




@Controller
@RequestMapping("/user")
public class UserController {
         @Autowired
	    private UserService userService;
             
     
	  @RequestMapping("/to/login")
	  public String tologin() {

		   return "login";
	  }
	  @RequestMapping("/login")
	  public String login(Employee employee,Model model,HttpSession session) {
		  Employee employee1 = userService.selectByEmployeeId(employee.getEmployeeId());
		  if(employee1==null) {
			  model.addAttribute("err", "社員IDは存在しません");
			  return "login";
		  }else {
			  Employee employee2 = userService.selectByEmployee(employee);
		  if(employee2==null) {
				  model.addAttribute("err", "パスワードが間違っています。再度入力をしてください");
				  return "login";  
		  }
		        }
		   if(employee1.getAuthority()==1) {
			  model.addAttribute("display", false);
			  session.setAttribute("employee", employee1);
			 
		  }else {
			  model.addAttribute("display", true);
			  session.setAttribute("employee", employee1);
		  }
		  return "index";
		  
	  }
	  @RequestMapping("/index")
	  public String toindex() { 
             
		  
			   return "/index";
		  }	

	  @RequestMapping("/勤怠情報一覧")
	  public String kilogin(HttpSession session, Model model) {
		  Employee  employee = (Employee)session.getAttribute("employee");
	      model.addAttribute("employee", employee);
	      int month = new Date().getMonth()+1;
	      int year = new Date().getYear();
	      int countWorkDay = GetWorkDay.countWorkDay(year, month);
	      int countAttendanceDay = userService.selectCountAttendanceDay(employee.getEmployeeId());
	      int absenceHours = userService.selectAbsenceHours(employee.getEmployeeId());
	      double workTime = userService.selectWorkTime(employee.getEmployeeId());
	      double overTimeHours = userService.selectOverTimeHours(employee.getEmployeeId());
	      model.addAttribute("month", month);
	      model.addAttribute("countWorkDay", countWorkDay);
	      model.addAttribute("countAttendanceDay", countAttendanceDay);
	      model.addAttribute("absenceHours", absenceHours);
	      model.addAttribute("workTime", workTime);
	      model.addAttribute("overTimeHours", overTimeHours);

		   return "勤怠情報一覧";
	  }
	  
	  @RequestMapping("/to/勤怠情報詳細")
      
	  public String test(HttpSession session,String year,String month,Model model) {
		  Employee  employee = (Employee)session.getAttribute("employee");
		  model.addAttribute("employee", employee);
		 String yearMonth = year+"/"+month;
		 List<Attendance> attendanceEmployee = userService.selectByAttendanceEmployee(yearMonth, employee.getEmployeeId());
		 model.addAttribute("attendanceEmployee", attendanceEmployee);       
		   return "勤怠情報詳細";
		   
		   
	  }
	  
	  @RequestMapping("/勤怠情報登録")
	  public String toloku(HttpSession session, Model model) {
    Employee  employee = (Employee)session.getAttribute("employee");		  
         model.addAttribute("employee", employee);
		  
		   return "勤怠情報登録";
	  }


	  
	  @RequestMapping("/社員情報一覧")
	  public String shlogin() {

		   return "社員情報一覧";
	  }


}
