package tologin.application.mapper;

import tologin.application.entity.Stock;

public interface StockMapper {
	public Stock selectByStock(Stock stock);
	public Stock selectById(Integer id);
	public Stock selectByName(String name);
	public Stock selectByUnit_id(String unit_id);
	public Stock selectByRemarks(String remarks);
}
