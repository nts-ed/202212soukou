package tologin.application.repository;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import tologin.application.entity.Stock;


@Repository
public class StockRepository {
	private final JdbcTemplate jdbcTemplate;
	
	public StockRepository(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	public void insertStock(Stock stock) {
		jdbcTemplate.update("INSERT INTO t_stock(name,unit_id,remarks,update_date) Values(?,?,?,now())",
			stock.getStock_name(),stock.getUnit_id(),stock.getRemarks());
	}
}
