package tologin.application.utill;

import java.util.Calendar;

public class GetWorkDay {
       
	
	public static int countWorkDay(int year,int month) {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.YEAR, year);
     
        c.set(Calendar.MONTH,month-1);
     
        int max = c.getActualMaximum(Calendar.DAY_OF_MONTH);
        
        int start =1;
      
        int count = 0;
        while(start <= max){
            c.set(Calendar.DAY_OF_MONTH,start);
            if(isWorkDay(c)){
                count++;
            }
            start++;
        }
        return count;
    }

    public static boolean isWorkDay(Calendar c){
    
        int week = c.get(Calendar.DAY_OF_WEEK);
       
        return week != Calendar.SUNDAY  && week != Calendar.SATURDAY;

    }
}
