package tologin.application.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tologin.application.entity.Stock;
import tologin.application.mapper.StockMapper;
import tologin.application.service.StockService;

@Service
public class StockServicelmpl implements StockService{
	 @Autowired
	 private StockMapper stockMapper;
	
	@Override
	public Stock selectByStock(Stock stock) {
		return stockMapper.selectByStock(stock);
	}
	
	@Override
	public Stock selectById(Integer id) {
		return stockMapper.selectById(id);
	}
	
	@Override
	public Stock selectByName(String name) {
		return stockMapper.selectByName(name);
	}
	
	@Override
	public Stock selectByUnit_id(String unit_id) {
		return stockMapper.selectByUnit_id(unit_id);
	}
	
	@Override 
	public Stock selectByRemarks(String remarks) {
		return stockMapper.selectByRemarks(remarks);
	}
	
}
