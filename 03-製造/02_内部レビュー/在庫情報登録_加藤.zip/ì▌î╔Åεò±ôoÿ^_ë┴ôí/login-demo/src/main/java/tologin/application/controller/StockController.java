package tologin.application.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import tologin.application.entity.Stock;
import tologin.application.form.StockForm;
import tologin.application.repository.StockRepository;

@Controller
@RequestMapping("/test")
public class StockController {
	private final StockRepository stockRepository;
	
	public StockController(StockRepository stockRepository) {
		this.stockRepository = stockRepository;
	}
	
	@RequestMapping("/to/在庫情報一覧")
	  public String list() { 
       
		  return "在庫情報一覧";
		  }	
	
	@RequestMapping("/to/在庫情報登録")
	  public String insert() { 
         
		  return "在庫情報登録";
		  }	

	@GetMapping()
	public String disp1(Model model) {
		model.addAttribute("stockForm", new StockForm());
		return "在庫情報登録";
	}
	
	@PostMapping("/update")
	public String disp2(StockForm stockForm) {
		Stock stock = new Stock();
		stock.setId(stockForm.getId());
		stock.setStock_name(stockForm.getStock_name());
		stock.setUnit_id(stockForm.getUnit_id());
		stock.setRemarks(stockForm.getRemarks());
		stockRepository.insertStock(stock);
		return "在庫情報一覧";
	}
	
}
