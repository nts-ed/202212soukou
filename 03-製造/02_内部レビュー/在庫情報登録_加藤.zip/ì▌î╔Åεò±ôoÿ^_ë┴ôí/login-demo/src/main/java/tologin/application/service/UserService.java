package tologin.application.service;

import java.util.List;

import tologin.application.entity.Attendance;
import tologin.application.entity.Employee;


public interface UserService {

	

	public Employee selectByEmployeeId(String employeeId );
	public Employee selectByEmployee(Employee employee );
	public int selectCountAttendanceDay(String employeeId);
	public int selectAbsenceHours(String employeeId);
	public double selectWorkTime(String employeeId);
	public double selectOverTimeHours(String employeeId);
	public List<Attendance> selectByAttendanceEmployee(String yearMonth,String employeeId );

}