package tologin.application.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tologin.application.entity.Attendance;
import tologin.application.entity.Employee;
import tologin.application.mapper.UserMapper;
import tologin.application.service.UserService;



@Service
public class UserServiceImpl implements UserService{
	  @Autowired
	  private UserMapper userMapper;


	@Override
	public Employee selectByEmployeeId(String employeeId) {
		
		return userMapper.selectByEmployeeId(employeeId);
	}

	@Override
	public Employee selectByEmployee(Employee employee) {
		
		return userMapper.selectByEmployee(employee);
	}

	@Override
	public int selectCountAttendanceDay(String employeeId) {
		
		return userMapper.selectCountAttendanceDay(employeeId);
	}

	@Override
	public int selectAbsenceHours(String employeeId) {
		
		return userMapper.selectAbsenceHours(employeeId);
	}

	@Override
	public double selectWorkTime(String employeeId) {
		// TODO Auto-generated method stub
		return userMapper.selectWorkTime(employeeId);
	}

	@Override
	public double selectOverTimeHours(String employeeId) {
		// TODO Auto-generated method stub
		return userMapper.selectOverTimeHours(employeeId);
	}

	@Override
	public List<Attendance> selectByAttendanceEmployee(String yearMonth, String employeeId) {
		
		return userMapper.selectByAttendanceEmployee(yearMonth, employeeId);
	}
	
}	
