package tologin.application.entity;

import java.util.Date;




public class Employee {

   private String employeeId;
   private String employeeName;
   private Date nyusyaDate; 
   private String sex;
   private Integer age;
   private String password;
   private String deptId;
   private String mailAddress;
   private Integer notificationFlg;
   private Integer authority;
   private Integer delFlg;
   private Date createDate; 
   private String createUser;
   
public String getEmployeeId() {
	return employeeId;
}
public void setEmployeeId(String employeeId) {
	this.employeeId = employeeId;
}
public String getEmployeeName() {
	return employeeName;
}
public void setEmployeeName(String employeeName) {
	this.employeeName = employeeName;
}
public Date getNyusyaDate() {
	return nyusyaDate;
}
public void setNyusyaDate(Date nyusyaDate) {
	this.nyusyaDate = nyusyaDate;
}
public String getSex() {
	return sex;
}
public void setSex(String sex) {
	this.sex = sex;
}
public Integer getAge() {
	return age;
}
public void setAge(Integer age) {
	this.age = age;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getDeptId() {
	return deptId;
}
public void setDeptId(String deptId) {
	this.deptId = deptId;
}
public String getMailAddress() {
	return mailAddress;
}
public void setMailAddress(String mailAddress) {
	this.mailAddress = mailAddress;
}
public Integer getNotificationFlg() {
	return notificationFlg;
}
public void setNotificationFlg(Integer notificationFlg) {
	this.notificationFlg = notificationFlg;
}
public Integer getAuthority() {
	return authority;
}
public void setAuthority(Integer authority) {
	this.authority = authority;
}
public Integer getDelFlg() {
	return delFlg;
}
public void setDelFlg(Integer delFlg) {
	this.delFlg = delFlg;
}
public Date getCreateDate() {
	return createDate;
}
public void setCreateDate(Date createDate) {
	this.createDate = createDate;
}
public String getCreateUser() {
	return createUser;
}
public void setCreateUser(String createUser) {
	this.createUser = createUser;
}
   


}

