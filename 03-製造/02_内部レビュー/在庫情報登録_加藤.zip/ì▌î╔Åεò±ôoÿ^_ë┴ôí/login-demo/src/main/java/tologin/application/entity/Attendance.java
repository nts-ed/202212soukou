package tologin.application.entity;

import java.util.Date;

public class Attendance {

	private  String employeeId;
	private  String attendanceDate;
	private  String startTime;
	private  String endTime;
	private  double restHours;
	private  double workingHours;
	private  double overTimeHours;
	private  double absenceHours;
	private  String statusId;
	private  String remarks;
	private  Date creatDate;
	private  String creatUser;
	private  Date update;
	private  String updateUser;
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getAttendanceDate() {
		return attendanceDate;
	}
	public void setAttendanceDate(String attendanceDate) {
		this.attendanceDate = attendanceDate;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public double getRestHours() {
		return restHours;
	}
	public void setRestHours(double restHours) {
		this.restHours = restHours;
	}
	public double getWorkingHours() {
		return workingHours;
	}
	public void setWorkingHours(double workingHours) {
		this.workingHours = workingHours;
	}
	public double getOverTimeHours() {
		return overTimeHours;
	}
	public void setOverTimeHours(double overTimeHours) {
		this.overTimeHours = overTimeHours;
	}
	public double getAbsenceHours() {
		return absenceHours;
	}
	public void setAbsenceHours(double absenceHours) {
		this.absenceHours = absenceHours;
	}
	public String getStatusId() {
		return statusId;
	}
	public void setStatusId(String statusId) {
		this.statusId = statusId;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public Date getCreatDate() {
		return creatDate;
	}
	public void setCreatDate(Date creatDate) {
		this.creatDate = creatDate;
	}
	public String getCreatUser() {
		return creatUser;
	}
	public void setCreatUser(String creatUser) {
		this.creatUser = creatUser;
	}
	public Date getUpdate() {
		return update;
	}
	public void setUpdate(Date update) {
		this.update = update;
	}
	public String getUpdateUser() {
		return updateUser;
	}
	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}
	@Override
	public String toString() {
		return "Attendance [employeeId=" + employeeId + ", attendanceDate=" + attendanceDate + ", startTime="
				+ startTime + ", endTime=" + endTime + ", restHours=" + restHours + ", workingHours=" + workingHours
				+ ", overTimeHours=" + overTimeHours + ", absenceHours=" + absenceHours + ", statusId=" + statusId
				+ ", remarks=" + remarks + ", creatDate=" + creatDate + ", creatUser=" + creatUser + ", update="
				+ update + ", updateUser=" + updateUser + "]";
	}
	
	
	
}