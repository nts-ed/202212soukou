package tologin.application.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tologin.application.entity.Stock;

import tologin.application.mapper.UserMapper;
import tologin.application.service.UserService;
import tologin.application.util.Search;

@Service
public class UserServiceImpl implements UserService {
	@Autowired
	private UserMapper userMapper;

	@Override
	public Stock selectByName(String name) {

		return userMapper.selectByName(name);
	}


	@Override
	public Stock selectByUpdateDate(Integer updateDate) {
		// TODO Auto-generated method stub
		return userMapper.selectByUpdateDate(updateDate);
	}

	@Override
	public Stock selectByStatus(String status) {
		// TODO Auto-generated method stub
		return userMapper.selectByStatus(status);
	}


	@Override
	public List<Stock> selectStock() {
		// TODO Auto-generated method stub
		return userMapper.selectStock();
		
		
	}


	@Override
	public List<Stock> selectStockPull(Search search) {
		// TODO Auto-generated method stub
		return userMapper.selectStockPull(search);
	}


	@Override
	public Integer deleteById(Integer id) {
		// TODO Auto-generated method stub
		return userMapper.deleteById(id);
	}


	
	


	

	

	
	
}


