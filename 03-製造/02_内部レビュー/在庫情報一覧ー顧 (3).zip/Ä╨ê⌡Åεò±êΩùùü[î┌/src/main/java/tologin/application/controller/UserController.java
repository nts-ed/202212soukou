package tologin.application.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import tologin.application.entity.Stock;
import tologin.application.service.UserService;
import tologin.application.util.Search;

@Controller

public class UserController {
	@Autowired
	private UserService userService;

	@RequestMapping("/to/stock")
	public String toStock(Model model) {

		List<Stock> stocks = userService.selectStock();
		model.addAttribute("stocks", stocks);
		System.out.println(stocks);
		return "在庫情報一覧";
	}

	@RequestMapping("/stock")
	public String stock(Model model, Search search) {
		if (search.getDateBegin() == "" && search.getDateEnd() == "" && search.getName() == "" && search.getStatus() == "") {
			return "在庫情報一覧";
		} else {
			System.out.println(search.getDateBegin());
			System.out.println(search.getDateEnd());
			System.out.println(search.getName());
			System.out.println(search.getStatus());
			List<Stock> stocks = userService.selectStockPull(search);
			System.out.println(stocks);
			model.addAttribute("stocks", stocks);
			
		}
		return "在庫情報一覧";

	}
	@RequestMapping("/delete")
	 public String delete(String id) {
	 return "在庫情報一覧";
	}
}