package tologin.application.service;

import java.util.List;

import tologin.application.entity.Stock;
import tologin.application.util.Search;

public interface UserService {

	public Stock selectByName(String name);

	public Stock selectByUpdateDate(Integer updateDate);

	public Stock selectByStatus(String status);

	public List<Stock> selectStock();
	
	public List<Stock>selectStockPull(Search search);
	
	public Integer deleteById(Integer id);
	
}
