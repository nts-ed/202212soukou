package tologin.application.entity;






public class goods {

	private String id;
	private String name;
	private String unit;
	private int currentAmount;
	private int operationAmount;
	private boolean operation;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public int getCurrentAmount() {
		return currentAmount;
	}
	public void setCurrentAmount(int currentAmount) {
		this.currentAmount = currentAmount;
	}
	public int getOperationAmount() {
		return operationAmount;
	}
	public void setOperationAmount(int operationAmount) {
		this.operationAmount = operationAmount;
	}
	public boolean isOperation() {
		return operation;
	}
	public void setOperation(boolean operation) {
		this.operation = operation;
	}
	
	

	

}
