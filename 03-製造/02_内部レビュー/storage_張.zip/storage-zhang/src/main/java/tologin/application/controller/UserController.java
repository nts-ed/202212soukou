package tologin.application.controller;



import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import tologin.application.entity.goods;
import tologin.application.entity.stockIO;
import tologin.application.service.UserService;




@Controller
@RequestMapping("/user")
public class UserController {
         @Autowired
	    private UserService userService;
		
        @GetMapping("/to/iosubmit")
		public String init() {
			return "iosubmit"; 
		}
         

	  @PostMapping("/to/iosubmit")
	  public String operation(String type, Integer operationAmount,Integer currentAmount,String name,String id, Model model,HttpSession session)
	  {	
		  if(operationAmount==null) {
			  model.addAttribute("err", "please enter value");
			  
		  }
		  else
		  
		  if("入庫".equals(type)) {
			  goods inputGoods=new goods();
			  stockIO IOLog=new stockIO();
			 if(currentAmount+operationAmount>99999)
			  {
				 model.addAttribute("err", "total number larger than 99999");
				 return "iosubmit";
			  }else
			  currentAmount=currentAmount+operationAmount;
			 inputGoods.setCurrentAmount(currentAmount);
			 IOLog.setId(id);
			 IOLog.setType1(type);
			 IOLog.setOpAmount(operationAmount);
			 IOLog.setUserName(name);
		//	 userService.insertInfo(inputGoods);
			 userService.insert(IOLog);
		  }
		 
		  else
			  if("出庫".equals(type)) {
				  goods outputGoods=new goods();
				  stockIO IOLog=new stockIO();
				  if(currentAmount-operationAmount<0)
				  {
					  
					 model.addAttribute("err", "decrease amount is larger than current amount");
					 return "iosubmit";
					 
				  }else
						 outputGoods.setCurrentAmount(currentAmount);
				  IOLog.setId(id);
					 IOLog.setType1(type);
					 IOLog.setOpAmount(operationAmount);
					 IOLog.setUserName(name);
			//		 userService.insertInfo(outputGoods);
					 userService.insert(IOLog);
			  }
	
   return "iosubmit";
   
	  }
			
	
	  
		 
	 
}
