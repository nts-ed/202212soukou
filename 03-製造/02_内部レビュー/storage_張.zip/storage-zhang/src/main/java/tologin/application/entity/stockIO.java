package tologin.application.entity;

public class stockIO {
	private String UserName;
	private String id;
	private String ioType;
	public String getIoType() {
		return ioType;
	}
	public void setIoType(String ioType) {
		this.ioType = ioType;
	}
	private String type1;
	private int opAmount;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}

	public String getUserName() {
		return UserName;
	}
	public void setUserName(String userName) {
		UserName = userName;
	}
	public String getType1() {
		return type1;
	}
	public void setType1(String type1) {
		this.type1 = type1;
	}
	public int getOpAmount() {
		return opAmount;
	}
	public void setOpAmount(int opAmount) {
		this.opAmount = opAmount;
	}
}
