package tologin.application.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import tologin.application.entity.goods;
import tologin.application.entity.stockIO;
import tologin.application.mapper.UserMapper;
import tologin.application.service.UserService;



@Service
public class UserServiceImpl implements UserService{
	  @Autowired
	  private UserMapper userMapper;

	@Override
	public goods insertInfo(goods shouhin) {
		// TODO Auto-generated method stub
		 return  userMapper.insertInfo(shouhin);
		
	}


	@Override
	public goods selectById(goods shouhin) {
		// TODO Auto-generated method stub
		return  userMapper.selectById(shouhin);
	}


	@Override
	public int insert(stockIO log) {
		// TODO Auto-generated method stub
		return userMapper.insert(log);
	}



}
