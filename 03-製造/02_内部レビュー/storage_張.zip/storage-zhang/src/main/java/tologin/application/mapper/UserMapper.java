package tologin.application.mapper;

import tologin.application.entity.goods;
import tologin.application.entity.stockIO;



public interface UserMapper {

	public  goods insertInfo(goods shouhin);
     public goods selectById(goods shouhin);
     public int insert(stockIO log);
}

